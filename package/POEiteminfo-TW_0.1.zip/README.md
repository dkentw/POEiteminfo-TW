POEiteminfo-TW
==============

POE tool for checking the info of item, this version is for Taiwan server.


## 安裝 ##
- 請先安裝 AutoHotKey v1.0.45 以上 [http://ahkscript.org/download/](http://ahkscript.org/download/)
- 下載整個 zip file
- 解壓後, 按右鍵讓 AutoHotkey 執行 POE-ItemInfo-tw.ahk 即可

### 注意事項 ###
- Data 資料夾要存在同一層目錄
- AutoHotKey 有兩種不同的版本, 請安裝以上連結所指的版本.


## Release ##
- v0.1: 初版, 大部份翻譯完成, 目前測試中, 複合詞諁有些有問題, 待處理中. 

## 已知問題 ##
- 複合詞綴有些無法正常判別 Tier
- 已經有網友提供傳奇的中文化, 但還沒有整合進來

## Credit ##
原英文版的資訊可以在底下找到, 感謝 Nipper 願意提供授權.

Thanks for Nipper4369 and original authors, if you want to check the original source please visit here:
[https://github.com/Nipper4369/POEiLvlandDPSDisplay](https://github.com/Nipper4369/POEiLvlandDPSDisplay)
